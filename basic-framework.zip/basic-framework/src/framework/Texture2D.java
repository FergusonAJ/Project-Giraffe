package framework;

import static JGL.JGL.*;



public class Texture2D extends Texture {

    public Texture2D() {
        super(GL_TEXTURE_2D);
    }
}